/**
 * ServicesSection — staggered service cards grid (Hebrew RTL)
 * Design: Cream bg, navy cards, copper accents, numbered display
 */
import { useEffect, useRef, useState } from "react";
import { Zap, Home, Building2, Sun, Shield, Wrench, Lightbulb, Activity } from "lucide-react";

const PANEL_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663517848114/PeTX8E4Esa6b2vTWxBJpq5/dave-panel-eY8tKGnDjxcoXxKxFXXyd7.webp";
const INSTALL_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663517848114/PeTX8E4Esa6b2vTWxBJpq5/dave-install-DsgzUcrTTfCaFh3ujdrXPS.webp";
const OUTDOOR_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663517848114/PeTX8E4Esa6b2vTWxBJpq5/dave-outdoor-nbwTrMjVbobiKjk63Khjbn.webp";

const services = [
  {
    num: "01",
    icon: Home,
    title: "חיווט למגורים",
    desc: "התקנות חשמליות מלאות בבתים, חיווט מחדש ושדרוגים. מבתים חדשים ועד לבתים ישנים — עשוי נכון בפעם הראשונה.",
    image: INSTALL_IMAGE,
  },
  {
    num: "02",
    icon: Building2,
    title: "חשמל מסחרי",
    desc: "בניינים משרדיים, חנויות וקבוצות תעשייתיות. אנחנו מטפלים במערכות בעומס גבוה, חשמל תלת-פאזי ותאימות לקוד.",
    image: OUTDOOR_IMAGE,
  },
  {
    num: "03",
    icon: Activity,
    title: "שדרוג לוח חשמל",
    desc: "לוח הפסקים ישן? אנחנו משדרגים ללוח מודרני 200A בבטחה ויעילות, משפרים בטיחות וקיבולת.",
    image: PANEL_IMAGE,
  },
  {
    num: "04",
    icon: Lightbulb,
    title: "תאורה חכמה",
    desc: "החלפות LED, מתגים חכמים, מערכות עמעום ובקרת תאורה אוטומטית לחיים מודרניים.",
    image: INSTALL_IMAGE,
  },
  {
    num: "05",
    icon: Zap,
    title: "תיקונים חירום",
    desc: "הפסקות חשמל, מפסקים שנפתחו, שקעים מנצנצים — אנחנו מגיבים במהירות, 24 שעות ביום, 7 ימים בשבוע.",
    image: PANEL_IMAGE,
  },
  {
    num: "06",
    icon: Sun,
    title: "התקנת טוען EV",
    desc: "תחנות טעינה ביתיות Level 2 מותקנות בצורה מקצועית. הכינו את הגראז שלכם לעתיד עם האמפראז הנכון.",
    image: OUTDOOR_IMAGE,
  },
];

function ServiceCard({ service, index, visible }: { service: typeof services[0]; index: number; visible: boolean }) {
  const { icon: Icon } = service;
  return (
    <div
      className="service-card rounded-xl overflow-hidden group"
      style={{
        background: "white",
        border: "1px solid oklch(0.88 0.02 255)",
        transitionDelay: `${index * 80}ms`,
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(30px)",
        transition: `opacity 0.5s ease ${index * 80}ms, transform 0.5s ease ${index * 80}ms, box-shadow 0.25s ease`,
        direction: "rtl",
      }}
    >
      {/* Image */}
      <div className="relative h-44 overflow-hidden">
        <img
          src={service.image}
          alt={service.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(to top, oklch(0.22 0.06 255 / 0.7) 0%, transparent 60%)" }}
        />
        {/* Number */}
        <span
          className="absolute top-3 left-3 text-4xl font-bold opacity-40"
          style={{ fontFamily: "Rubik, sans-serif", color: "oklch(0.65 0.14 55)" }}
        >
          {service.num}
        </span>
      </div>

      {/* Content */}
      <div className="p-5">
        <div className="flex items-center gap-3 mb-3">
          <div
            className="w-9 h-9 rounded flex items-center justify-center shrink-0"
            style={{ background: "oklch(0.65 0.14 55 / 0.12)" }}
          >
            <Icon className="w-5 h-5" style={{ color: "oklch(0.65 0.14 55)" }} />
          </div>
          <h3
            className="text-lg font-bold"
            style={{ fontFamily: "Rubik, sans-serif", color: "oklch(0.22 0.06 255)" }}
          >
            {service.title}
          </h3>
        </div>
        <p
          className="text-sm leading-relaxed"
          style={{ color: "oklch(0.45 0.04 255)", fontFamily: "Rubik, sans-serif" }}
        >
          {service.desc}
        </p>
        <a
          href="#contact"
          className="inline-flex items-center gap-1 mt-4 text-sm font-semibold transition-colors hover:gap-2"
          style={{ color: "oklch(0.65 0.14 55)", fontFamily: "Rubik, sans-serif", direction: "rtl" }}
        >
          קבל הצעת מחיר ←
        </a>
      </div>
    </div>
  );
}

export default function ServicesSection() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="services"
      ref={ref}
      className="py-20 lg:py-28"
      style={{ background: "oklch(0.97 0.01 80)", direction: "rtl" }}
    >
      <div className="container">
        {/* Header */}
        <div className="mb-14">
          <p
            className="text-xs font-bold tracking-[0.2em] uppercase mb-3"
            style={{ color: "oklch(0.65 0.14 55)", fontFamily: "Rubik, sans-serif" }}
          >
            מה אנחנו עושים
          </p>
          <h2
            className="text-4xl lg:text-5xl font-bold copper-underline"
            style={{ fontFamily: "Rubik, sans-serif", color: "oklch(0.22 0.06 255)" }}
          >
            השירותים שלנו
          </h2>
          <p
            className="mt-6 text-lg max-w-xl"
            style={{ color: "oklch(0.45 0.04 255)", fontFamily: "Rubik, sans-serif" }}
          >
            מתיקונים חירום ועד להתקנות מלאות, דייב מטפל בכל צורך חשמלי בדיוק ובטיפול.
          </p>
        </div>

        {/* Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, i) => (
            <ServiceCard key={service.num} service={service} index={i} visible={visible} />
          ))}
        </div>
      </div>
    </section>
  );
}
