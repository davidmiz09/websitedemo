/**
 * WhyDaveSection — "Why Choose Dave" with feature highlights (Hebrew RTL)
 * Design: Navy bg, copper icons, asymmetric layout with image
 */
import { useEffect, useRef, useState } from "react";
import { CheckCircle2, Award, Clock3, ThumbsUp, Wrench, Phone } from "lucide-react";

const INSTALL_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663517848114/PeTX8E4Esa6b2vTWxBJpq5/dave-install-DsgzUcrTTfCaFh3ujdrXPS.webp";

const features = [
  {
    icon: Award,
    title: "רישיון חשמלאי ראשי",
    desc: "מורשה לחלוטין, מובטח ומסוכן. אנחנו עומדים בכל הקודים המקומיים והממלכתיים בכל פעם.",
  },
  {
    icon: Clock3,
    title: "ערובת בזמן",
    desc: "אנחנו מופיעים כשאנחנו אומרים שנופיע. הזמן שלך יקר — אנחנו מכבדים את זה.",
  },
  {
    icon: ThumbsUp,
    title: "תמחור שקוף",
    desc: "ללא עמלות נסתרות. אתה מקבל הצעה ברורה לפני שתחל כל עבודה.",
  },
  {
    icon: Wrench,
    title: "עבודה נקייה",
    desc: "אנחנו משאירים את הבית שלך נקי יותר מכפי שמצאנו אותו. עבודה מסודרת, בכל פעם.",
  },
  {
    icon: CheckCircle2,
    title: "שביעות רצון מובטחת",
    desc: "לא מרוצה? אנחנו חוזרים ומתקנים את זה — ללא שאלות.",
  },
  {
    icon: Phone,
    title: "אדם אמיתי עונה",
    desc: "התקשר אלינו ואדם אמיתי יענה. ללא תפריטים אוטומטיים, ללא עיכובים.",
  },
];

export default function WhyDaveSection() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="about"
      ref={ref}
      className="py-20 lg:py-28 overflow-hidden"
      style={{ background: "oklch(0.22 0.06 255)", direction: "rtl" }}
    >
      <div className="container">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left: Image */}
          <div
            className={`relative transition-all duration-700 ${visible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-12"}`}
          >
            <div
              className="rounded-2xl overflow-hidden"
              style={{ boxShadow: "0 32px 64px oklch(0 0 0 / 0.4)" }}
            >
              <img
                src={INSTALL_IMAGE}
                alt="דייב עובד על התקנה חשמלית"
                className="w-full h-[480px] object-cover"
              />
            </div>
            {/* Copper border accent */}
            <div
              className="absolute -bottom-4 -right-4 w-full h-full rounded-2xl -z-10"
              style={{ border: "2px solid oklch(0.65 0.14 55 / 0.4)" }}
            />
            {/* Certification badge */}
            <div
              className="absolute top-6 -left-6 px-4 py-3 rounded-xl shadow-xl"
              style={{
                background: "oklch(0.65 0.14 55)",
                color: "white",
                direction: "rtl",
              }}
            >
              <p className="text-xs font-bold uppercase tracking-wider" style={{ fontFamily: "Rubik, sans-serif" }}>
                מוסמך
              </p>
              <p className="text-lg font-bold" style={{ fontFamily: "Rubik, sans-serif" }}>
                חשמלאי ראשי
              </p>
            </div>
          </div>

          {/* Right: Content */}
          <div
            className={`transition-all duration-700 delay-200 ${visible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-12"}`}
          >
            <p
              className="text-xs font-bold tracking-[0.2em] uppercase mb-3"
              style={{ color: "oklch(0.65 0.14 55)", fontFamily: "Rubik, sans-serif" }}
            >
              למה לבחור בנו
            </p>
            <h2
              className="text-4xl lg:text-5xl font-bold mb-4 leading-tight"
              style={{ fontFamily: "Rubik, sans-serif", color: "white" }}
            >
              ההבדל של
              <br />
              <span style={{ color: "oklch(0.65 0.14 55)" }}>דייב</span>
            </h2>
            <p
              className="text-base leading-relaxed mb-10"
              style={{ color: "oklch(0.78 0.03 255)", fontFamily: "Rubik, sans-serif" }}
            >
              דייב התחיל את הקריירה שלו כשהוא היה בן 18 ומעולם לא הפסיק ללמוד. היום, הוא מוביל צוות שמתייחס לבית של כל לקוח כאילו הוא שלהם.
            </p>

            {/* Features grid */}
            <div className="grid sm:grid-cols-2 gap-5">
              {features.map(({ icon: Icon, title, desc }, i) => (
                <div
                  key={title}
                  className="flex gap-3"
                  style={{
                    opacity: visible ? 1 : 0,
                    transform: visible ? "translateY(0)" : "translateY(20px)",
                    transition: `opacity 0.5s ease ${200 + i * 80}ms, transform 0.5s ease ${200 + i * 80}ms`,
                    direction: "rtl",
                  }}
                >
                  <div
                    className="w-9 h-9 rounded shrink-0 flex items-center justify-center mt-0.5"
                    style={{ background: "oklch(0.65 0.14 55 / 0.15)" }}
                  >
                    <Icon className="w-4 h-4" style={{ color: "oklch(0.65 0.14 55)" }} />
                  </div>
                  <div>
                    <p
                      className="font-bold text-sm mb-0.5"
                      style={{ color: "white", fontFamily: "Rubik, sans-serif", fontSize: "1rem" }}
                    >
                      {title}
                    </p>
                    <p
                      className="text-sm leading-relaxed"
                      style={{ color: "oklch(0.65 0.05 255)", fontFamily: "Rubik, sans-serif" }}
                    >
                      {desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
