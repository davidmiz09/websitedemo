/**
 * HeroSection — asymmetric layout, left text + right image (Hebrew RTL)
 * Design: Navy bg, copper accents, Rubik display text, animated entrance
 */
import { useEffect, useState } from "react";
import { Zap, Shield, Clock, ChevronDown } from "lucide-react";

const HERO_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663517848114/PeTX8E4Esa6b2vTWxBJpq5/dave-hero-DxRVKBV6zqPYLtaEmtEjbK.webp";

export default function HeroSection() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(t);
  }, []);

  return (
    <section
      id="home"
      className="relative min-h-[90vh] flex items-center overflow-hidden"
      style={{ background: "oklch(0.22 0.06 255)", direction: "rtl" }}
    >
      {/* Background circuit pattern */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `
            linear-gradient(oklch(0.65 0.14 55 / 0.3) 1px, transparent 1px),
            linear-gradient(90deg, oklch(0.65 0.14 55 / 0.3) 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Radial glow */}
      <div
        className="absolute top-0 right-0 w-[60%] h-full opacity-20"
        style={{
          background: "radial-gradient(ellipse at 80% 50%, oklch(0.65 0.14 55), transparent 70%)",
        }}
      />

      <div className="container relative z-10 py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left: Text content */}
          <div className={`transition-all duration-700 ${visible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-12"}`}>
            {/* Badge */}
            <div
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold tracking-widest uppercase mb-6 float-badge"
              style={{
                background: "oklch(0.65 0.14 55 / 0.2)",
                border: "1px solid oklch(0.65 0.14 55 / 0.5)",
                color: "oklch(0.75 0.12 55)",
                fontFamily: "Rubik, sans-serif",
                direction: "rtl",
              }}
            >
              <Zap className="w-3 h-3 fill-current" />
              חשמלאי ראשי מורשה ומבוטח
            </div>

            {/* Headline */}
            <h1
              className="text-5xl lg:text-7xl font-bold leading-none tracking-tight mb-6"
              style={{ fontFamily: "Rubik, sans-serif", color: "white", direction: "rtl" }}
            >
              הנח את הביטחון
              <br />
              בידיים של
              <br />
              <span style={{ color: "oklch(0.65 0.14 55)" }}>מומחה</span>
            </h1>

            <p
              className="text-lg leading-relaxed mb-8 max-w-lg"
              style={{ color: "oklch(0.78 0.03 255)", fontFamily: "Rubik, sans-serif", direction: "rtl" }}
            >
              דייב מביא 15+ שנות ניסיון בעבודות חשמל מקצועיות לכל עבודה — מתיקונים פשוטים ועד לחיווט מלא. מהיר, אמין, ותמיד בזמן.
            </p>

            {/* Trust badges */}
            <div className="flex flex-wrap gap-4 mb-10">
              {[
                { icon: Shield, text: "מורשה לחלוטין" },
                { icon: Clock, text: "חירום 24/7" },
                { icon: Zap, text: "שירות ביום הקבלה" },
              ].map(({ icon: Icon, text }) => (
                <div
                  key={text}
                  className="flex items-center gap-2 px-3 py-2 rounded"
                  style={{
                    background: "oklch(0.30 0.07 255)",
                    color: "oklch(0.85 0.02 255)",
                    fontFamily: "Rubik, sans-serif",
                    fontSize: "0.875rem",
                    fontWeight: 600,
                    direction: "rtl",
                  }}
                >
                  <Icon className="w-4 h-4" style={{ color: "oklch(0.65 0.14 55)" }} />
                  {text}
                </div>
              ))}
            </div>

            {/* CTAs */}
            <div className="flex flex-wrap gap-4">
              <a
                href="#contact"
                className="px-8 py-4 rounded font-bold text-base uppercase tracking-wider transition-all duration-200 hover:scale-105 hover:shadow-xl"
                style={{
                  background: "oklch(0.65 0.14 55)",
                  color: "white",
                  fontFamily: "Rubik, sans-serif",
                  letterSpacing: "0.08em",
                  boxShadow: "0 8px 24px oklch(0.65 0.14 55 / 0.4)",
                  direction: "rtl",
                }}
              >
                קבל הצעת מחיר חינם
              </a>
              <a
                href="tel:+15551234567"
                className="px-8 py-4 rounded font-bold text-base uppercase tracking-wider transition-all duration-200 hover:scale-105"
                style={{
                  border: "2px solid oklch(0.65 0.14 55 / 0.6)",
                  color: "oklch(0.75 0.12 55)",
                  fontFamily: "Rubik, sans-serif",
                  letterSpacing: "0.08em",
                  direction: "rtl",
                }}
              >
                (555) 123-4567
              </a>
            </div>
          </div>

          {/* Right: Image */}
          <div
            className={`relative transition-all duration-700 delay-200 ${visible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-12"}`}
          >
            {/* Image frame */}
            <div
              className="relative rounded-2xl overflow-hidden"
              style={{
                boxShadow: "0 32px 64px oklch(0 0 0 / 0.5), 0 0 0 1px oklch(0.65 0.14 55 / 0.3)",
              }}
            >
              <img
                src={HERO_IMAGE}
                alt="דייב — חשמלאי מקצועי"
                className="w-full h-[500px] object-cover"
              />
              {/* Overlay gradient */}
              <div
                className="absolute inset-0"
                style={{
                  background: "linear-gradient(to top, oklch(0.22 0.06 255 / 0.6) 0%, transparent 50%)",
                }}
              />
            </div>

            {/* Floating review badge */}
            <div
              className="absolute -bottom-6 -left-6 px-5 py-4 rounded-xl shadow-2xl float-badge"
              style={{
                background: "oklch(0.97 0.01 80)",
                border: "2px solid oklch(0.65 0.14 55 / 0.3)",
                direction: "rtl",
              }}
            >
              <div className="flex items-center gap-1 mb-1">
                {[...Array(5)].map((_, i) => (
                  <span key={i} className="text-lg" style={{ color: "oklch(0.65 0.14 55)" }}>★</span>
                ))}
              </div>
              <p className="text-xs font-bold" style={{ color: "oklch(0.22 0.06 255)", fontFamily: "Rubik, sans-serif" }}>
                דירוג 5.0
              </p>
              <p className="text-xs" style={{ color: "oklch(0.50 0.04 255)", fontFamily: "Rubik, sans-serif" }}>
                200+ ביקורות
              </p>
            </div>

            {/* Experience badge */}
            <div
              className="absolute -top-4 -right-4 w-20 h-20 rounded-full flex flex-col items-center justify-center shadow-xl float-badge"
              style={{
                background: "oklch(0.65 0.14 55)",
              }}
            >
              <span
                className="text-2xl font-bold text-white leading-none"
                style={{ fontFamily: "Rubik, sans-serif" }}
              >
                15+
              </span>
              <span
                className="text-xs text-white/80 text-center leading-tight"
                style={{ fontFamily: "Rubik, sans-serif" }}
              >
                שנות ניסיון
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <a
        href="#services"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 opacity-60 hover:opacity-100 transition-opacity"
        style={{ color: "oklch(0.65 0.14 55)" }}
      >
        <span className="text-xs uppercase tracking-widest" style={{ fontFamily: "Rubik, sans-serif" }}>
          גלול
        </span>
        <ChevronDown className="w-5 h-5 animate-bounce" />
      </a>
    </section>
  );
}
