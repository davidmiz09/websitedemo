/**
 * ReviewsSection — fake positive customer reviews carousel (Hebrew RTL)
 * Design: Cream bg, navy cards with copper stars, auto-scrolling
 */
import { useEffect, useRef, useState } from "react";
import { Quote, ChevronLeft, ChevronRight } from "lucide-react";

const reviews = [
  {
    name: "שרה מ.",
    location: "צד מערבי, קליפורניה",
    rating: 5,
    date: "מרץ 2026",
    text: "דייב חיווט מחדש לחלוטין את הבית שלנו מ-1960 והההבדל הוא ממש בולט. הוא היה מקצועי, נקי והסביר הכל בבירור. בחום מומלץ!",
    avatar: "שמ",
    job: "חיווט בית מלא",
  },
  {
    name: "ג'יימס ט.",
    location: "מרכז העיר, קליפורניה",
    rating: 5,
    date: "פברואר 2026",
    text: "התקשרתי בשעה 23:00 עבור שקע מנצנץ ודייב הגיע תוך 45 דקות. תיקן את הבעיה במהירות ובדק את שאר הלוח בחינם. אגדה!",
    avatar: "גט",
    job: "תיקון חירום",
  },
  {
    name: "לינדה וביל ק.",
    location: "אוק פארק, קליפורניה",
    rating: 5,
    date: "פברואר 2026",
    text: "דייב התקין טוענים EV בשני גרגים שלנו. עבודה מסודרת, מחיר טוב, וגם עזר לנו להבין את תהליך ההחזר. 10/10.",
    avatar: "לק",
    job: "התקנת טוען EV",
  },
  {
    name: "מרקוס ר.",
    location: "נורת'ריג, קליפורניה",
    rating: 5,
    date: "ינואר 2026",
    text: "דייב שדרג את הלוח שלנו מ-100A ל-200A. כל העבודה הושלמה ביום אחד ועברה בדיקה בפעם הראשונה. מאוד מרוצה מהידע שלו.",
    avatar: "מר",
    job: "שדרוג לוח",
  },
  {
    name: "פריה ס.",
    location: "סילבר לייק, קליפורניה",
    rating: 5,
    date: "ינואר 2026",
    text: "התקנת תאורה חכמה בכל הבית. דייב היה סבלני עם כל השאלות שלי ועזר לנו להגדיר את האפליקציה. הבית שלנו נראה מדהים!",
    avatar: "פס",
    job: "תאורה חכמה",
  },
  {
    name: "טום ואנג'לה וו.",
    location: "פסדינה, קליפורניה",
    rating: 5,
    date: "דצמבר 2025",
    text: "השתמשנו בדייב לשלוש עבודות שונות כבר. בכל פעם: בזמן, מחיר הוגן, עבודה מעולה. הוא החשמלאי היחיד שנתקשר אליו.",
    avatar: "טו",
    job: "לקוח קבוע",
  },
  {
    name: "קרלוס ו.",
    location: "בורבנק, קליפורניה",
    rating: 5,
    date: "דצמבר 2025",
    text: "דייב טיפל בחשמל לשיפוץ המסעדה שלנו. עבד סביב לוח הזמנים שלנו והעבודה הייתה ללא פגע. המפקח שלנו אמר שזו התקנה הנקייה ביותר שראה.",
    avatar: "קו",
    job: "חיווט מסחרי",
  },
  {
    name: "רייצ'ל ח.",
    location: "גלנדייל, קליפורניה",
    rating: 5,
    date: "נובמבר 2025",
    text: "הייתי חוששת מהעלות של חיווט מחדש אבל דייב נתן לי הצעה הוגנת וקבעה אותה. ללא הפתעות. בחור כן עושה עבודה מעולה.",
    avatar: "רח",
    job: "חיווט חלקי",
  },
];

function StarRating({ count }: { count: number }) {
  return (
    <div className="flex gap-0.5">
      {[...Array(count)].map((_, i) => (
        <span key={i} className="text-base" style={{ color: "oklch(0.65 0.14 55)" }}>★</span>
      ))}
    </div>
  );
}

function ReviewCard({ review }: { review: typeof reviews[0] }) {
  return (
    <div
      className="review-card flex-shrink-0 w-80 rounded-xl p-6 relative"
      style={{
        background: "white",
        border: "1px solid oklch(0.88 0.02 255)",
        boxShadow: "0 4px 16px oklch(0.22 0.06 255 / 0.06)",
        direction: "rtl",
      }}
    >
      {/* Quote icon */}
      <Quote
        className="absolute top-4 left-4 w-8 h-8 opacity-10"
        style={{ color: "oklch(0.65 0.14 55)" }}
      />

      {/* Stars */}
      <StarRating count={review.rating} />

      {/* Job tag */}
      <span
        className="inline-block mt-2 mb-3 px-2 py-0.5 rounded text-xs font-semibold"
        style={{
          background: "oklch(0.65 0.14 55 / 0.1)",
          color: "oklch(0.55 0.14 55)",
          fontFamily: "Rubik, sans-serif",
        }}
      >
        {review.job}
      </span>

      {/* Review text */}
      <p
        className="text-sm leading-relaxed mb-5"
        style={{ color: "oklch(0.40 0.04 255)", fontFamily: "Rubik, sans-serif" }}
      >
        "{review.text}"
      </p>

      {/* Reviewer */}
      <div className="flex items-center gap-3">
        <div
          className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold shrink-0"
          style={{
            background: "oklch(0.22 0.06 255)",
            color: "oklch(0.65 0.14 55)",
            fontFamily: "Rubik, sans-serif",
          }}
        >
          {review.avatar}
        </div>
        <div>
          <p
            className="font-bold text-sm"
            style={{ color: "oklch(0.22 0.06 255)", fontFamily: "Rubik, sans-serif" }}
          >
            {review.name}
          </p>
          <p
            className="text-xs"
            style={{ color: "oklch(0.60 0.04 255)", fontFamily: "Rubik, sans-serif" }}
          >
            {review.location} · {review.date}
          </p>
        </div>
      </div>
    </div>
  );
}

export default function ReviewsSection() {
  const trackRef = useRef<HTMLDivElement>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const visibleCount = 3;
  const maxIndex = reviews.length - visibleCount;

  const scrollTo = (index: number) => {
    const clamped = Math.max(0, Math.min(index, maxIndex));
    setCurrentIndex(clamped);
    if (trackRef.current) {
      const cardWidth = 320 + 24;
      trackRef.current.scrollTo({ left: clamped * cardWidth, behavior: "smooth" });
    }
  };

  // Auto-scroll
  useEffect(() => {
    if (isPaused) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => {
        const next = prev >= maxIndex ? 0 : prev + 1;
        if (trackRef.current) {
          const cardWidth = 320 + 24;
          trackRef.current.scrollTo({ left: next * cardWidth, behavior: "smooth" });
        }
        return next;
      });
    }, 3500);
    return () => clearInterval(interval);
  }, [isPaused, maxIndex]);

  return (
    <section
      id="reviews"
      className="py-20 lg:py-28"
      style={{ background: "oklch(0.97 0.01 80)", direction: "rtl" }}
    >
      <div className="container">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-12">
          <div>
            <p
              className="text-xs font-bold tracking-[0.2em] uppercase mb-3"
              style={{ color: "oklch(0.65 0.14 55)", fontFamily: "Rubik, sans-serif" }}
            >
              ביקורות לקוחות
            </p>
            <h2
              className="text-4xl lg:text-5xl font-bold copper-underline"
              style={{ fontFamily: "Rubik, sans-serif", color: "oklch(0.22 0.06 255)" }}
            >
              מה אנשים אומרים
            </h2>
          </div>

          {/* Overall rating widget */}
          <div
            className="flex items-center gap-4 px-6 py-4 rounded-xl shrink-0"
            style={{
              background: "oklch(0.22 0.06 255)",
              color: "white",
              direction: "rtl",
            }}
          >
            <div className="text-center">
              <p
                className="text-4xl font-bold leading-none"
                style={{ fontFamily: "Rubik, sans-serif", color: "oklch(0.65 0.14 55)" }}
              >
                5.0
              </p>
              <StarRating count={5} />
              <p
                className="text-xs mt-1 opacity-70"
                style={{ fontFamily: "Rubik, sans-serif" }}
              >
                200+ ביקורות
              </p>
            </div>
            <div
              className="w-px h-12 opacity-30"
              style={{ background: "oklch(0.65 0.14 55)" }}
            />
            <div className="text-sm" style={{ fontFamily: "Rubik, sans-serif" }}>
              {[5, 4, 3, 2, 1].map((star) => (
                <div key={star} className="flex items-center gap-2 mb-1">
                  <span className="text-xs w-2">{star}</span>
                  <div className="w-20 h-1.5 rounded-full overflow-hidden" style={{ background: "oklch(0.35 0.07 255)" }}>
                    <div
                      className="h-full rounded-full"
                      style={{
                        background: "oklch(0.65 0.14 55)",
                        width: star === 5 ? "96%" : star === 4 ? "3%" : "1%",
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Carousel */}
        <div
          className="relative"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
        >
          <div
            ref={trackRef}
            className="flex gap-6 overflow-x-auto pb-4 scroll-smooth"
            style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
          >
            {reviews.map((review) => (
              <ReviewCard key={review.name} review={review} />
            ))}
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-center gap-3 mt-8">
            <button
              onClick={() => scrollTo(currentIndex - 1)}
              disabled={currentIndex === 0}
              className="w-10 h-10 rounded-full flex items-center justify-center transition-all hover:scale-110 disabled:opacity-30"
              style={{
                background: "oklch(0.22 0.06 255)",
                color: "white",
              }}
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            {/* Dots */}
            <div className="flex gap-2">
              {Array.from({ length: maxIndex + 1 }).map((_, i) => (
                <button
                  key={i}
                  onClick={() => scrollTo(i)}
                  className="rounded-full transition-all duration-300"
                  style={{
                    width: i === currentIndex ? "24px" : "8px",
                    height: "8px",
                    background: i === currentIndex ? "oklch(0.65 0.14 55)" : "oklch(0.80 0.02 255)",
                  }}
                />
              ))}
            </div>

            <button
              onClick={() => scrollTo(currentIndex + 1)}
              disabled={currentIndex >= maxIndex}
              className="w-10 h-10 rounded-full flex items-center justify-center transition-all hover:scale-110 disabled:opacity-30"
              style={{
                background: "oklch(0.22 0.06 255)",
                color: "white",
              }}
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
