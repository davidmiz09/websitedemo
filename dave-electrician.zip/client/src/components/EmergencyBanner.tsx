/**
 * EmergencyBanner — top strip for 24/7 emergency calls (Hebrew RTL)
 * Design: copper background, navy text, dismissible
 */
import { useState } from "react";
import { Zap, Phone, X } from "lucide-react";

export default function EmergencyBanner() {
  const [visible, setVisible] = useState(true);
  if (!visible) return null;

  return (
    <div
      className="relative flex items-center justify-center gap-3 px-4 py-2 text-sm font-semibold"
      style={{ background: "oklch(0.65 0.14 55)", color: "oklch(0.22 0.06 255)" }}
    >
      <Zap className="w-4 h-4 bolt-animate shrink-0" />
      <span className="font-['Rubik']">
        ⚡ שירות חשמלי חירום 24/7 זמין — התקשר עכשיו:
      </span>
      <a
        href="tel:+15551234567"
        className="flex items-center gap-1 font-bold underline underline-offset-2 hover:opacity-80 transition-opacity"
        style={{ fontFamily: "Rubik, sans-serif" }}
      >
        <Phone className="w-3.5 h-3.5" />
        (555) 123-4567
      </a>
      <button
        onClick={() => setVisible(false)}
        className="absolute left-3 top-1/2 -translate-y-1/2 hover:opacity-70 transition-opacity"
        aria-label="סגור"
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  );
}
