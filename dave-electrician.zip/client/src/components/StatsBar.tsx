/**
 * StatsBar — animated counter stats band (Hebrew RTL)
 * Design: Copper background, navy text, Rubik numbers
 */
import { useEffect, useRef, useState } from "react";

const stats = [
  { value: 1200, suffix: "+", label: "עבודות שהושלמו" },
  { value: 15, suffix: "+", label: "שנות ניסיון" },
  { value: 200, suffix: "+", label: "ביקורות 5 כוכבים" },
  { value: 24, suffix: "/7", label: "שירות חירום" },
];

function useCountUp(target: number, duration = 1800, active: boolean) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!active) return;
    let start = 0;
    const step = target / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, 16);
    return () => clearInterval(timer);
  }, [target, duration, active]);
  return count;
}

function StatItem({ value, suffix, label, active }: { value: number; suffix: string; label: string; active: boolean }) {
  const count = useCountUp(value, 1800, active);
  return (
    <div className="flex flex-col items-center gap-1 py-6 px-4" style={{ direction: "rtl" }}>
      <span
        className="text-4xl lg:text-5xl font-bold leading-none"
        style={{ fontFamily: "Rubik, sans-serif", color: "oklch(0.22 0.06 255)" }}
      >
        {count.toLocaleString()}{suffix}
      </span>
      <span
        className="text-sm font-semibold uppercase tracking-widest"
        style={{ color: "oklch(0.30 0.07 255)", fontFamily: "Rubik, sans-serif" }}
      >
        {label}
      </span>
    </div>
  );
}

export default function StatsBar() {
  const ref = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setActive(true); },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className="relative"
      style={{ background: "oklch(0.65 0.14 55)", direction: "rtl" }}
    >
      {/* Top diagonal cut */}
      <div
        className="absolute top-0 left-0 right-0 h-6 -translate-y-full"
        style={{
          background: "oklch(0.65 0.14 55)",
          clipPath: "polygon(0 100%, 100% 100%, 100% 0)",
        }}
      />
      <div className="container">
        <div className="grid grid-cols-2 lg:grid-cols-4 divide-x divide-[oklch(0.55_0.14_55)]">
          {stats.map((s) => (
            <StatItem key={s.label} {...s} active={active} />
          ))}
        </div>
      </div>
    </div>
  );
}
