/**
 * Navbar — sticky top navigation (Hebrew RTL)
 * Design: Navy background, copper accent on active/hover, Rubik logo
 */
import { useState, useEffect } from "react";
import { Zap, Menu, X, Phone } from "lucide-react";

const navLinks = [
  { label: "בית", href: "#home" },
  { label: "שירותים", href: "#services" },
  { label: "אודות", href: "#about" },
  { label: "ביקורות", href: "#reviews" },
  { label: "יצירת קשר", href: "#contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className="sticky top-0 z-50 transition-all duration-300"
      style={{
        background: scrolled
          ? "oklch(0.22 0.06 255 / 0.97)"
          : "oklch(0.22 0.06 255)",
        backdropFilter: scrolled ? "blur(12px)" : "none",
        boxShadow: scrolled ? "0 4px 24px oklch(0 0 0 / 0.3)" : "none",
        direction: "rtl",
      }}
    >
      <div className="container flex items-center justify-between h-16">
        {/* Logo */}
        <a href="#home" className="flex items-center gap-2 group">
          <span
            className="text-xl font-bold tracking-wide"
            style={{
              fontFamily: "Rubik, sans-serif",
              color: "oklch(0.97 0.01 80)",
            }}
          >
            <span style={{ color: "oklch(0.65 0.14 55)" }}>DAVE'S</span> ELECTRIC
          </span>
          <div
            className="w-9 h-9 rounded flex items-center justify-center bolt-animate"
            style={{ background: "oklch(0.65 0.14 55)" }}
          >
            <Zap className="w-5 h-5 text-white fill-white" />
          </div>
        </a>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="text-sm font-semibold tracking-wider uppercase transition-colors duration-200 hover:text-[oklch(0.75_0.12_55)]"
              style={{
                fontFamily: "Rubik, sans-serif",
                color: "oklch(0.85 0.02 255)",
              }}
            >
              {link.label}
            </a>
          ))}
        </div>

        {/* CTA */}
        <a
          href="tel:+15551234567"
          className="hidden md:flex items-center gap-2 px-4 py-2 rounded font-bold text-sm transition-all duration-200 hover:scale-105 hover:shadow-lg"
          style={{
            background: "oklch(0.65 0.14 55)",
            color: "white",
            fontFamily: "Rubik, sans-serif",
            letterSpacing: "0.05em",
          }}
        >
          <Phone className="w-4 h-4" />
          התקשר עכשיו
        </a>

        {/* Mobile menu button */}
        <button
          className="md:hidden p-2 rounded"
          style={{ color: "oklch(0.97 0.01 80)" }}
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="תפריט"
        >
          {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div
          className="md:hidden border-t px-4 py-4 flex flex-col gap-4"
          style={{
            background: "oklch(0.22 0.06 255)",
            borderColor: "oklch(0.35 0.07 255)",
            direction: "rtl",
          }}
        >
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="text-base font-semibold tracking-wider uppercase"
              style={{ color: "oklch(0.85 0.02 255)", fontFamily: "Rubik, sans-serif" }}
              onClick={() => setMenuOpen(false)}
            >
              {link.label}
            </a>
          ))}
          <a
            href="tel:+15551234567"
            className="flex items-center justify-center gap-2 px-4 py-3 rounded font-bold text-sm mt-2"
            style={{
              background: "oklch(0.65 0.14 55)",
              color: "white",
              fontFamily: "Rubik, sans-serif",
            }}
          >
            <Phone className="w-4 h-4" />
            (555) 123-4567
          </a>
        </div>
      )}
    </nav>
  );
}
