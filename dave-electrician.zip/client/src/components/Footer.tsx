/**
 * Footer — site footer with links and copyright (Hebrew RTL)
 * Design: Deep navy, copper accents
 */
import { Zap, Phone, Mail, MapPin, Facebook, Instagram, Twitter } from "lucide-react";

export default function Footer() {
  return (
    <footer style={{ background: "oklch(0.16 0.05 255)", direction: "rtl" }}>
      <div className="container py-14">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <span
                className="text-xl font-bold tracking-wide"
                style={{ fontFamily: "Rubik, sans-serif", color: "white" }}
              >
                <span style={{ color: "oklch(0.65 0.14 55)" }}>DAVE'S</span> ELECTRIC
              </span>
              <div
                className="w-9 h-9 rounded flex items-center justify-center"
                style={{ background: "oklch(0.65 0.14 55)" }}
              >
                <Zap className="w-5 h-5 text-white fill-white" />
              </div>
            </div>
            <p
              className="text-sm leading-relaxed mb-5"
              style={{ color: "oklch(0.65 0.05 255)", fontFamily: "Rubik, sans-serif" }}
            >
              חשמלאי ראשי מורשה המשרת את אזור לוס אנג'לס מאז 2010. עבודה איכותית, תמחור הוגן.
            </p>
            <div className="flex gap-3">
              {[Facebook, Instagram, Twitter].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-9 h-9 rounded flex items-center justify-center transition-all hover:scale-110"
                  style={{
                    background: "oklch(0.30 0.07 255)",
                    color: "oklch(0.65 0.14 55)",
                  }}
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Services */}
          <div>
            <h4
              className="text-sm font-bold uppercase tracking-widest mb-4"
              style={{ fontFamily: "Rubik, sans-serif", color: "oklch(0.65 0.14 55)" }}
            >
              שירותים
            </h4>
            <ul className="space-y-2">
              {[
                "חיווט למגורים",
                "חשמל מסחרי",
                "שדרוג לוח",
                "תאורה חכמה",
                "תיקונים חירום",
                "התקנת טוען EV",
              ].map((s) => (
                <li key={s}>
                  <a
                    href="#services"
                    className="text-sm hover:text-[oklch(0.75_0.12_55)] transition-colors"
                    style={{ color: "oklch(0.65 0.05 255)", fontFamily: "Rubik, sans-serif" }}
                  >
                    {s}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h4
              className="text-sm font-bold uppercase tracking-widest mb-4"
              style={{ fontFamily: "Rubik, sans-serif", color: "oklch(0.65 0.14 55)" }}
            >
              קישורים מהירים
            </h4>
            <ul className="space-y-2">
              {[
                { label: "בית", href: "#home" },
                { label: "אודות דייב", href: "#about" },
                { label: "ביקורות", href: "#reviews" },
                { label: "יצירת קשר", href: "#contact" },
                { label: "קבל הצעת מחיר חינם", href: "#contact" },
              ].map(({ label, href }) => (
                <li key={label}>
                  <a
                    href={href}
                    className="text-sm hover:text-[oklch(0.75_0.12_55)] transition-colors"
                    style={{ color: "oklch(0.65 0.05 255)", fontFamily: "Rubik, sans-serif" }}
                  >
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4
              className="text-sm font-bold uppercase tracking-widest mb-4"
              style={{ fontFamily: "Rubik, sans-serif", color: "oklch(0.65 0.14 55)" }}
            >
              צור קשר
            </h4>
            <div className="space-y-3">
              {[
                { icon: Phone, text: "(555) 123-4567", href: "tel:+15551234567" },
                { icon: Mail, text: "dave@daveselectric.com", href: "mailto:dave@daveselectric.com" },
                { icon: MapPin, text: "לוס אנג'לס, קליפורניה", href: null },
              ].map(({ icon: Icon, text, href }) => (
                <div key={text} className="flex items-center gap-2">
                  <Icon className="w-4 h-4 shrink-0" style={{ color: "oklch(0.65 0.14 55)" }} />
                  {href ? (
                    <a
                      href={href}
                      className="text-sm hover:text-[oklch(0.75_0.12_55)] transition-colors"
                      style={{ color: "oklch(0.65 0.05 255)", fontFamily: "Rubik, sans-serif" }}
                    >
                      {text}
                    </a>
                  ) : (
                    <span
                      className="text-sm"
                      style={{ color: "oklch(0.65 0.05 255)", fontFamily: "Rubik, sans-serif" }}
                    >
                      {text}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div
          className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-3"
          style={{ borderTop: "1px solid oklch(0.30 0.07 255)", direction: "rtl" }}
        >
          <p
            className="text-xs"
            style={{ color: "oklch(0.50 0.04 255)", fontFamily: "Rubik, sans-serif" }}
          >
            © 2026 Dave's Electric. כל הזכויות שמורות. רישיון #EC-789456
          </p>
          <div className="flex gap-4">
            {["מדיניות פרטיות", "תנאי שימוש"].map((link) => (
              <a
                key={link}
                href="#"
                className="text-xs hover:text-[oklch(0.75_0.12_55)] transition-colors"
                style={{ color: "oklch(0.50 0.04 255)", fontFamily: "Rubik, sans-serif" }}
              >
                {link}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
