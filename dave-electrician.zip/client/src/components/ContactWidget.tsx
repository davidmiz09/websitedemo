/**
 * ContactWidget — contact form + info section (Hebrew RTL)
 * Design: Navy bg, copper accents, clean form layout
 */
import { useState } from "react";
import { Phone, Mail, MapPin, Clock, Send, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

export default function ContactWidget() {
  const [form, setForm] = useState({ name: "", phone: "", email: "", service: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    toast.success("ההודעה נשלחה! דייב יתקשר אליך בתוך שעתיים.", {
      duration: 5000,
    });
  };

  return (
    <section
      id="contact"
      className="py-20 lg:py-28"
      style={{ background: "oklch(0.22 0.06 255)", direction: "rtl" }}
    >
      <div className="container">
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Left: Info */}
          <div>
            <p
              className="text-xs font-bold tracking-[0.2em] uppercase mb-3"
              style={{ color: "oklch(0.65 0.14 55)", fontFamily: "Rubik, sans-serif" }}
            >
              צור קשר
            </p>
            <h2
              className="text-4xl lg:text-5xl font-bold mb-6 leading-tight"
              style={{ fontFamily: "Rubik, sans-serif", color: "white" }}
            >
              קבל הצעה
              <br />
              <span style={{ color: "oklch(0.65 0.14 55)" }}>חינם</span>
            </h2>
            <p
              className="text-base leading-relaxed mb-10"
              style={{ color: "oklch(0.78 0.03 255)", fontFamily: "Rubik, sans-serif" }}
            >
              מלא את הטופס ודייב יתקשר אליך בחזרה תוך שעתיים עם הערכה חינם, ללא התחייבות.
            </p>

            {/* Contact info */}
            <div className="space-y-5">
              {[
                { icon: Phone, label: "טלפון", value: "(555) 123-4567", href: "tel:+15551234567" },
                { icon: Mail, label: "דוא״ל", value: "dave@daveselectric.com", href: "mailto:dave@daveselectric.com" },
                { icon: MapPin, label: "אזור שירות", value: "לוס אנג'לס ואזורים סמוכים", href: null },
                { icon: Clock, label: "שעות", value: "ב׳-ו׳ 7:00-20:00 | חירום 24/7", href: null },
              ].map(({ icon: Icon, label, value, href }) => (
                <div key={label} className="flex items-start gap-4">
                  <div
                    className="w-10 h-10 rounded flex items-center justify-center shrink-0 mt-0.5"
                    style={{ background: "oklch(0.65 0.14 55 / 0.15)" }}
                  >
                    <Icon className="w-5 h-5" style={{ color: "oklch(0.65 0.14 55)" }} />
                  </div>
                  <div>
                    <p
                      className="text-xs font-bold uppercase tracking-wider mb-0.5"
                      style={{ color: "oklch(0.65 0.14 55)", fontFamily: "Rubik, sans-serif" }}
                    >
                      {label}
                    </p>
                    {href ? (
                      <a
                        href={href}
                        className="text-base hover:text-[oklch(0.75_0.12_55)] transition-colors"
                        style={{ color: "oklch(0.85 0.02 255)", fontFamily: "Rubik, sans-serif" }}
                      >
                        {value}
                      </a>
                    ) : (
                      <p
                        className="text-base"
                        style={{ color: "oklch(0.85 0.02 255)", fontFamily: "Rubik, sans-serif" }}
                      >
                        {value}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Form */}
          <div
            className="rounded-2xl p-8"
            style={{
              background: "oklch(0.30 0.07 255)",
              border: "1px solid oklch(0.40 0.07 255)",
              direction: "rtl",
            }}
          >
            {submitted ? (
              <div className="flex flex-col items-center justify-center h-full py-12 text-center gap-4">
                <CheckCircle2 className="w-16 h-16" style={{ color: "oklch(0.65 0.14 55)" }} />
                <h3
                  className="text-2xl font-bold"
                  style={{ fontFamily: "Rubik, sans-serif", color: "white" }}
                >
                  ההודעה נשלחה!
                </h3>
                <p style={{ color: "oklch(0.78 0.03 255)", fontFamily: "Rubik, sans-serif" }}>
                  דייב יתקשר אליך בתוך שעתיים עם הצעת המחיר החינם שלך.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-4 text-sm underline"
                  style={{ color: "oklch(0.65 0.14 55)", fontFamily: "Rubik, sans-serif" }}
                >
                  שלח הודעה נוספת
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <h3
                  className="text-xl font-bold mb-6"
                  style={{ fontFamily: "Rubik, sans-serif", color: "white" }}
                >
                  בקש הצעת מחיר חינם
                </h3>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label
                      className="block text-xs font-bold uppercase tracking-wider mb-1.5"
                      style={{ color: "oklch(0.65 0.14 55)", fontFamily: "Rubik, sans-serif" }}
                    >
                      שמך *
                    </label>
                    <input
                      required
                      type="text"
                      placeholder="יוחנן כהן"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="w-full px-4 py-3 rounded text-sm outline-none transition-all"
                      style={{
                        background: "oklch(0.22 0.06 255)",
                        border: "1px solid oklch(0.40 0.07 255)",
                        color: "white",
                        fontFamily: "Rubik, sans-serif",
                        direction: "rtl",
                      }}
                    />
                  </div>
                  <div>
                    <label
                      className="block text-xs font-bold uppercase tracking-wider mb-1.5"
                      style={{ color: "oklch(0.65 0.14 55)", fontFamily: "Rubik, sans-serif" }}
                    >
                      טלפון *
                    </label>
                    <input
                      required
                      type="tel"
                      placeholder="(555) 000-0000"
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      className="w-full px-4 py-3 rounded text-sm outline-none transition-all"
                      style={{
                        background: "oklch(0.22 0.06 255)",
                        border: "1px solid oklch(0.40 0.07 255)",
                        color: "white",
                        fontFamily: "Rubik, sans-serif",
                        direction: "rtl",
                      }}
                    />
                  </div>
                </div>

                <div>
                  <label
                    className="block text-xs font-bold uppercase tracking-wider mb-1.5"
                    style={{ color: "oklch(0.65 0.14 55)", fontFamily: "Rubik, sans-serif" }}
                  >
                    דוא״ל
                  </label>
                  <input
                    type="email"
                    placeholder="you@example.com"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    className="w-full px-4 py-3 rounded text-sm outline-none transition-all"
                    style={{
                      background: "oklch(0.22 0.06 255)",
                      border: "1px solid oklch(0.40 0.07 255)",
                      color: "white",
                      fontFamily: "Rubik, sans-serif",
                      direction: "rtl",
                    }}
                  />
                </div>

                <div>
                  <label
                    className="block text-xs font-bold uppercase tracking-wider mb-1.5"
                    style={{ color: "oklch(0.65 0.14 55)", fontFamily: "Rubik, sans-serif" }}
                  >
                    שירות נדרש
                  </label>
                  <select
                    value={form.service}
                    onChange={(e) => setForm({ ...form, service: e.target.value })}
                    className="w-full px-4 py-3 rounded text-sm outline-none transition-all"
                    style={{
                      background: "oklch(0.22 0.06 255)",
                      border: "1px solid oklch(0.40 0.07 255)",
                      color: form.service ? "white" : "oklch(0.60 0.04 255)",
                      fontFamily: "Rubik, sans-serif",
                      direction: "rtl",
                    }}
                  >
                    <option value="" disabled>בחר שירות...</option>
                    <option value="residential">חיווט למגורים</option>
                    <option value="commercial">חשמל מסחרי</option>
                    <option value="panel">שדרוג לוח</option>
                    <option value="lighting">תאורה חכמה</option>
                    <option value="emergency">תיקון חירום</option>
                    <option value="ev">התקנת טוען EV</option>
                    <option value="other">אחר</option>
                  </select>
                </div>

                <div>
                  <label
                    className="block text-xs font-bold uppercase tracking-wider mb-1.5"
                    style={{ color: "oklch(0.65 0.14 55)", fontFamily: "Rubik, sans-serif" }}
                  >
                    הודעה
                  </label>
                  <textarea
                    rows={3}
                    placeholder="תאר את הצרכים החשמליים שלך..."
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    className="w-full px-4 py-3 rounded text-sm outline-none transition-all resize-none"
                    style={{
                      background: "oklch(0.22 0.06 255)",
                      border: "1px solid oklch(0.40 0.07 255)",
                      color: "white",
                      fontFamily: "Rubik, sans-serif",
                      direction: "rtl",
                    }}
                  />
                </div>

                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-2 py-4 rounded font-bold text-base uppercase tracking-wider transition-all hover:scale-[1.02] hover:shadow-xl"
                  style={{
                    background: "oklch(0.65 0.14 55)",
                    color: "white",
                    fontFamily: "Rubik, sans-serif",
                    letterSpacing: "0.08em",
                    boxShadow: "0 8px 24px oklch(0.65 0.14 55 / 0.35)",
                    direction: "rtl",
                  }}
                >
                  <Send className="w-4 h-4" />
                  שלח את בקשתי
                </button>

                <p
                  className="text-center text-xs"
                  style={{ color: "oklch(0.60 0.04 255)", fontFamily: "Rubik, sans-serif" }}
                >
                  נחזור אליך בתוך שעתיים. ללא ספאם, לעולם.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
