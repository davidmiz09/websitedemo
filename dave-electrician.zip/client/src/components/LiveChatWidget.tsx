/**
 * LiveChatWidget — floating chat bubble with simulated chat (Hebrew RTL)
 * Design: Copper button, navy chat window, animated messages
 */
import { useState, useEffect, useRef } from "react";
import { MessageCircle, X, Send, Zap } from "lucide-react";

const BOT_MESSAGES = [
  "שלום! 👋 אני העוזר של דייב. איך אוכל לעזור לך?",
  "אנחנו מציעים הצעות חינם על כל העבודות! איזה סוג של עבודה חשמלית אתה צריך?",
  "דייב זמין לשירות ביום הקבלה ברוב המקרים. האם אתה רוצה לתזמן ביקור?",
];

const QUICK_REPLIES = [
  "קבל הצעת מחיר חינם",
  "תיקון חירום",
  "מה התעריפים שלכם?",
  "תזמן ביקור",
];

type Message = {
  from: "bot" | "user";
  text: string;
  time: string;
};

function getTime() {
  return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

export default function LiveChatWidget() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const [notified, setNotified] = useState(false);
  const [pulse, setPulse] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const botIndex = useRef(0);

  // Initial greeting after delay
  useEffect(() => {
    const t = setTimeout(() => {
      setMessages([{ from: "bot", text: BOT_MESSAGES[0], time: getTime() }]);
      botIndex.current = 1;
      setNotified(true);
      setPulse(true);
      setTimeout(() => setPulse(false), 3000);
    }, 2500);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, typing]);

  const sendBotReply = () => {
    setTyping(true);
    setTimeout(() => {
      const msg = BOT_MESSAGES[botIndex.current % BOT_MESSAGES.length] ||
        "תודה על הפנייה! דייב יחזור אליך בקרוב. אתה יכול גם להתקשר ל-(555) 123-4567 לעזרה מיידית.";
      botIndex.current++;
      setMessages((prev) => [...prev, { from: "bot", text: msg, time: getTime() }]);
      setTyping(false);
    }, 1200 + Math.random() * 800);
  };

  const handleSend = (text: string = input.trim()) => {
    if (!text) return;
    setMessages((prev) => [...prev, { from: "user", text, time: getTime() }]);
    setInput("");
    sendBotReply();
  };

  return (
    <>
      {/* Chat window */}
      {open && (
        <div
          className="fixed bottom-24 right-6 z-50 w-80 rounded-2xl overflow-hidden shadow-2xl flex flex-col"
          style={{
            background: "oklch(0.22 0.06 255)",
            border: "1px solid oklch(0.40 0.07 255)",
            maxHeight: "480px",
            direction: "rtl",
          }}
        >
          {/* Header */}
          <div
            className="flex items-center justify-between px-4 py-3"
            style={{ background: "oklch(0.65 0.14 55)" }}
          >
            <button
              onClick={() => setOpen(false)}
              className="text-white/80 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <div>
              <p className="text-sm font-bold text-white" style={{ fontFamily: "Rubik, sans-serif" }}>
                Dave's Electric
              </p>
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 rounded-full bg-green-400" />
                <p className="text-xs text-white/80" style={{ fontFamily: "Rubik, sans-serif" }}>
                  זמין עכשיו
                </p>
              </div>
            </div>
            <div
              className="w-9 h-9 rounded-full flex items-center justify-center"
              style={{ background: "oklch(0.22 0.06 255)" }}
            >
              <Zap className="w-5 h-5 fill-current" style={{ color: "oklch(0.65 0.14 55)" }} />
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3" style={{ minHeight: 0, maxHeight: "280px" }}>
            {messages.map((msg, i) => (
              <div
                key={i}
                className={`flex ${msg.from === "user" ? "justify-start" : "justify-end"}`}
              >
                <div
                  className="max-w-[85%] px-3 py-2 rounded-xl text-sm"
                  style={{
                    background: msg.from === "user" ? "oklch(0.65 0.14 55)" : "oklch(0.30 0.07 255)",
                    color: "white",
                    fontFamily: "Rubik, sans-serif",
                    borderRadius: msg.from === "user" ? "12px 2px 12px 12px" : "2px 12px 12px 12px",
                    direction: "rtl",
                  }}
                >
                  <p>{msg.text}</p>
                  <p className="text-xs mt-1 opacity-60 text-right">{msg.time}</p>
                </div>
              </div>
            ))}
            {typing && (
              <div className="flex justify-end">
                <div
                  className="px-4 py-3 rounded-xl"
                  style={{ background: "oklch(0.30 0.07 255)", borderRadius: "2px 12px 12px 12px" }}
                >
                  <div className="flex gap-1">
                    {[0, 1, 2].map((i) => (
                      <div
                        key={i}
                        className="w-2 h-2 rounded-full animate-bounce"
                        style={{
                          background: "oklch(0.65 0.14 55)",
                          animationDelay: `${i * 150}ms`,
                        }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Quick replies */}
          <div className="px-4 pb-2 flex flex-wrap gap-2">
            {QUICK_REPLIES.map((reply) => (
              <button
                key={reply}
                onClick={() => handleSend(reply)}
                className="text-xs px-3 py-1.5 rounded-full transition-all hover:scale-105"
                style={{
                  border: "1px solid oklch(0.65 0.14 55 / 0.5)",
                  color: "oklch(0.75 0.12 55)",
                  fontFamily: "Rubik, sans-serif",
                }}
              >
                {reply}
              </button>
            ))}
          </div>

          {/* Input */}
          <div
            className="flex items-center gap-2 px-4 py-3"
            style={{ borderTop: "1px solid oklch(0.35 0.07 255)", direction: "rtl" }}
          >
            <button
              onClick={() => handleSend()}
              className="w-8 h-8 rounded-full flex items-center justify-center transition-all hover:scale-110"
              style={{ background: "oklch(0.65 0.14 55)" }}
            >
              <Send className="w-4 h-4 text-white" />
            </button>
            <input
              type="text"
              placeholder="הקלד הודעה..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              className="flex-1 bg-transparent text-sm outline-none"
              style={{
                color: "white",
                fontFamily: "Rubik, sans-serif",
                direction: "rtl",
              }}
            />
          </div>
        </div>
      )}

      {/* Floating button */}
      <button
        onClick={() => { setOpen(!open); setNotified(false); }}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full flex items-center justify-center shadow-2xl transition-all hover:scale-110"
        style={{
          background: "oklch(0.65 0.14 55)",
          boxShadow: pulse
            ? "0 0 0 0 oklch(0.65 0.14 55 / 0.6), 0 8px 24px oklch(0.65 0.14 55 / 0.4)"
            : "0 8px 24px oklch(0.65 0.14 55 / 0.4)",
          animation: pulse ? "pulse-chat 1s ease-out 3" : "none",
        }}
        aria-label="פתח צ'אט"
      >
        {open ? (
          <X className="w-6 h-6 text-white" />
        ) : (
          <MessageCircle className="w-6 h-6 text-white fill-white" />
        )}
        {/* Notification dot */}
        {notified && !open && (
          <span
            className="absolute top-0 right-0 w-4 h-4 rounded-full flex items-center justify-center text-xs font-bold"
            style={{ background: "#ef4444", color: "white", fontFamily: "Rubik, sans-serif" }}
          >
            1
          </span>
        )}
      </button>

      <style>{`
        @keyframes pulse-chat {
          0% { box-shadow: 0 0 0 0 oklch(0.65 0.14 55 / 0.6), 0 8px 24px oklch(0.65 0.14 55 / 0.4); }
          70% { box-shadow: 0 0 0 16px oklch(0.65 0.14 55 / 0), 0 8px 24px oklch(0.65 0.14 55 / 0.4); }
          100% { box-shadow: 0 0 0 0 oklch(0.65 0.14 55 / 0), 0 8px 24px oklch(0.65 0.14 55 / 0.4); }
        }
      `}</style>
    </>
  );
}
