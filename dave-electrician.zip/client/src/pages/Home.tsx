/**
 * Dave's Electric — Home Page
 * Design: Modern Craftsman (Navy #0F2044 + Copper #E8852A)
 * Fonts: Oswald (headings) + Source Sans 3 (body)
 * Layout: Asymmetric hero, staggered service grid, animated stats, review carousel
 */

import { useEffect, useRef, useState } from "react";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import StatsBar from "@/components/StatsBar";
import ServicesSection from "@/components/ServicesSection";
import WhyDaveSection from "@/components/WhyDaveSection";
import ReviewsSection from "@/components/ReviewsSection";
import ContactWidget from "@/components/ContactWidget";
import Footer from "@/components/Footer";
import LiveChatWidget from "@/components/LiveChatWidget";
import EmergencyBanner from "@/components/EmergencyBanner";

export default function Home() {
  return (
    <div className="min-h-screen overflow-x-hidden">
      <EmergencyBanner />
      <Navbar />
      <HeroSection />
      <StatsBar />
      <ServicesSection />
      <WhyDaveSection />
      <ReviewsSection />
      <ContactWidget />
      <Footer />
      <LiveChatWidget />
    </div>
  );
}
