# Design Brainstorm: Dave's Electric

## Three Design Directions

<response>
<text>
**Approach A: Industrial Brutalism with Electric Accents**
- **Design Movement**: Neo-Brutalism meets Industrial Craft
- **Core Principles**: Raw honesty, bold contrast, tactile texture, no-nonsense professionalism
- **Color Philosophy**: Deep charcoal (#1a1a1a) base with electric yellow (#FFD600) as the primary accent — evoking high-voltage energy and warning tape. White text for legibility.
- **Layout Paradigm**: Asymmetric grid with offset cards, diagonal section dividers, heavy borders on key elements
- **Signature Elements**: Diagonal yellow "caution tape" stripes as dividers, thick black borders on cards, lightning bolt motifs
- **Interaction Philosophy**: Snappy hover states with border color flips, bold scale transforms
- **Animation**: Fast, punchy transitions (150ms ease-in). Cards lift sharply on hover. Section reveals with slide-up.
- **Typography System**: "Barlow Condensed" (bold, uppercase) for headings + "IBM Plex Sans" for body. Strong hierarchy with large display numbers.
</text>
<probability>0.08</probability>
</response>

<response>
<text>
**Approach B: Clean Professional with Deep Navy & Copper (CHOSEN)**
- **Design Movement**: Modern Craftsman — precision meets warmth
- **Core Principles**: Trust-building clarity, premium service feel, structured hierarchy, confident simplicity
- **Color Philosophy**: Deep navy (#0F2044) as primary background for authority, warm copper/amber (#E8852A) as accent for energy and warmth, off-white (#F8F5F0) for content areas. This palette says "reliable expert."
- **Layout Paradigm**: Asymmetric hero with left-anchored text + right image panel. Services in a staggered card grid. Stats bar as a full-width band. Reviews in a horizontal scroll carousel.
- **Signature Elements**: Copper-colored lightning bolt icon as brand mark, subtle circuit-board pattern as background texture, numbered service cards with large display numbers
- **Interaction Philosophy**: Smooth, confident hover states. Buttons pulse subtly. Review cards tilt slightly on hover.
- **Animation**: Medium pace (250ms ease-out). Hero text staggers in. Stat counters animate up on scroll. Cards fade+slide on viewport entry.
- **Typography System**: "Oswald" (condensed, bold) for headings + "Source Sans 3" for body. Large display numbers for stats.
</text>
<probability>0.09</probability>
</response>

<response>
<text>
**Approach C: Bright & Approachable with Sky Blue & Sunshine**
- **Design Movement**: Friendly Modernism — approachable expertise
- **Core Principles**: Warmth, accessibility, community trust, cheerful professionalism
- **Color Philosophy**: Sky blue (#2563EB) primary with sunshine yellow (#FBBF24) accent. Clean white backgrounds. Feels like a neighborhood business you can trust.
- **Layout Paradigm**: Centered hero with large illustration, three-column service grid, testimonial masonry wall
- **Signature Elements**: Rounded pill badges, soft drop shadows, illustrated icons for each service
- **Interaction Philosophy**: Gentle bouncy animations, color fills on hover, friendly micro-interactions
- **Animation**: Springy transitions (300ms spring). Floating badge animations. Staggered grid reveals.
- **Typography System**: "Plus Jakarta Sans" throughout with varied weights. Playful but readable.
</text>
<probability>0.07</probability>
</response>

## Selected Approach: B — Modern Craftsman (Navy + Copper)

Deep navy authority + copper warmth = the perfect electrician brand. Professional enough to win commercial contracts, warm enough to attract homeowners.
